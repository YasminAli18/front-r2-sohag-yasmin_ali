const { src, dest,series } = require("gulp");
const htmlmin = require("gulp-html-minifier-terser");
const concat = require("gulp-concat");
const cleanCSS = require("gulp-clean-css");
const terser = require("gulp-terser");
const optimizeImg = require("gulp-optimize-images");



function htmlTask() {
  return src("project/*.html")
    .pipe(htmlmin({ removeComments: true, collapseWhitespace: true }))
    .pipe(dest("dist"));
}

exports.html = htmlTask;

function cssTask() {
  return src("project/css/**/*.css")
    .pipe(concat("style.min.css"))
    .pipe(cleanCSS())
    .pipe(dest("dist/Css"));
}
exports.css = cssTask;

function jsTask() {
  return src("project/js/**/*.js")
    .pipe(concat("script.min.js"))
    .pipe(terser())
    .pipe(dest("dist/Js"));
}
exports.js = jsTask;

function imgTask() {
  return src("project/pics/*", { encoding: false })
    .pipe(
      optimizeImg({
        compressOptions: {
          jpeg: { quality: 60 },
        },
      })
    )
    .pipe(dest("dist/images"));
}
exports.img = imgTask;


exports.default =series(htmlTask, cssTask, jsTask, imgTask);